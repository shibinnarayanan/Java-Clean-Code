package com.code.normal;

public class Bank {

	public static double getDiscount(double type, int amount) {
		if (type == 1) {
			return amount * 0.1;
		}
		if (type == 2) {
			return amount * 0.2;
		}
		if (type == 3) {
			return amount * 0.3;
		}

		return amount;
	}

	public static void main(String[] args) {

		System.out.println(Bank.getDiscount(2, 300));
		System.out.println(Bank.getDiscount(1, 300));

	}
}
