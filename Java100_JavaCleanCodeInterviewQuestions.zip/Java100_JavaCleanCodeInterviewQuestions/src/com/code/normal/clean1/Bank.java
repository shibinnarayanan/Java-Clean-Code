package com.code.normal.clean1;

import java.util.HashMap;
import java.util.Map;

public class Bank {

	public Bank() {
		initMap();
	}

	private enum Type {
		Type1, Type2, Type3
	}

	Map<Type, Double> mapType = new HashMap<Type, Double>();

	void initMap() {
		mapType.put(Type.Type1, 0.1);
		mapType.put(Type.Type2, 0.2);
		mapType.put(Type.Type3, 0.3);
	}

	public double getDiscount(Type type, double amount) {

		return amount * (mapType.get(type) != null ? mapType.get(type) : 1);

	}

	public static void main(String[] args) {

		Bank bank = new Bank();

		System.out.println(bank.getDiscount(Type.Type1, 300));
		System.out.println(bank.getDiscount(Type.Type2, 300));
		System.out.println(bank.getDiscount(Type.Type3, 300));

	}
}
