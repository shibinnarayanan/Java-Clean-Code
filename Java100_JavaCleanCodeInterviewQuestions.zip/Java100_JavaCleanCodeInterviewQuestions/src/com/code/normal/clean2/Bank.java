package com.code.normal.clean2;

import java.util.HashMap;
import java.util.Map;

public class Bank {

	private final static double disc1 = 0.1;
	private final static double disc2 = 0.2;
	private final static double disc3 = 0.3;

	private enum Type {
		Type1 {
			@Override
			double getDiscount(double amount) {
				// TODO Auto-generated method stub
				return amount * disc1;
			}
		},
		Type2 {
			@Override
			double getDiscount(double amount) {
				// TODO Auto-generated method stub
				return amount * disc2;
			}
		},
		Type3 {
			@Override
			double getDiscount(double amount) {
				// TODO Auto-generated method stub
				return amount * disc3;
			}
		};

		abstract double getDiscount(double amount);
	}

	public static void main(String[] args) {

		System.out.println(Type.Type1.getDiscount(300));
		System.out.println(Type.Type2.getDiscount(300));
		System.out.println(Type.Type3.getDiscount(300));

	}
}
