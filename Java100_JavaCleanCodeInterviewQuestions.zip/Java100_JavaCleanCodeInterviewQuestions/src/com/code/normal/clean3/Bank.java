package com.code.normal.clean3;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class Bank {

	private final static double disc1 = 0.1;
	private final static double disc2 = 0.2;
	private final static double disc3 = 0.3;

	private enum Type {

		Type1(Bank::getDiscount1), Type2(Bank::getDiscount2), Type3(Bank::getDiscount3);

		Function<Double, Double> getDiscount;

		private Type(Function<Double, Double> getDiscount) {
			this.getDiscount = getDiscount;
		}

	}

	public static void main(String[] args) {

		System.out.println(Type.Type1.getDiscount.apply(300.0));
		System.out.println(Type.Type2.getDiscount.apply(300.00));
		System.out.println(Type.Type3.getDiscount.apply(300.00));

	}

	public static double getDiscount1(double amount) {
		return amount * disc1;
	}

	public static double getDiscount2(double amount) {
		return amount * disc2;
	}

	public static double getDiscount3(double amount) {
		return amount * disc3;
	}
}
